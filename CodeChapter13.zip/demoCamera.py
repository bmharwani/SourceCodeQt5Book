import android

app = android.Android()
app.cameraInteractiveCapturePicture("/sdcard/cameraPic.jpg")
